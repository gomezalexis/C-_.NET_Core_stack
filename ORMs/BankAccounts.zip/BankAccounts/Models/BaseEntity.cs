namespace BankAccounts.Models
{
    public abstract class BaseEntity
    {
        
    }
}